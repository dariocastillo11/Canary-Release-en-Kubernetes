const http = require('http');
const fs = require('fs');
const path = require('path');

const version = process.env.VERSION || 'v1';

const server = http.createServer((req, res) => {
  let htmlFile = 'index.html';
  let cssFile = 'styles.css';

  // Usa archivos diferentes según la versión
  if (version.includes('v2')) {
    htmlFile = 'index-v2.html';
    cssFile = 'styles-v2.css';
  }

  if (req.url === '/' || req.url === '/index.html') {
    fs.readFile(path.join(__dirname, htmlFile), 'utf8', (err, data) => {
      if (err) {
        res.writeHead(500);
        return res.end('Error cargando index.html');
      }
      // Inyecta la versión en el HTML
      const html = data.replace('window.VERSION || \'Versión desconocida\'', `'${version}'`);
      res.writeHead(200, {'Content-Type': 'text/html'});
      res.end(html);
    });
  } else if (req.url === '/styles.css') {
    fs.readFile(path.join(__dirname, cssFile), (err, data) => {
      if (err) {
        res.writeHead(404);
        return res.end('No encontrado');
      }
      res.writeHead(200, {'Content-Type': 'text/css'});
      res.end(data);
    });
  } else {
    res.writeHead(404);
    res.end('No encontrado');
  }
});

server.listen(80, () => {
  console.log(`Servidor iniciado en puerto 80 - ${version}`);
});